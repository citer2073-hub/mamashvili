# Project structure after cleanup

## Main app files
- `src/main.tsx` — single React/Vite entry point
- `src/App.tsx` — main application component
- `index.html` — Vite root HTML file
- `public/` — static public assets

## Deployment/config
- `firebase.json` — Firebase Hosting config (`dist` as public output)
- `.firebaserc` — Firebase project alias
- `.github/workflows/deploy.yml` — GitHub Actions auto-deploy workflow
- `package.json` — dependencies and scripts
- `vite.config.ts` — Vite config
- `tsconfig.json`, `tsconfig.node.json` — TypeScript config

## Backups moved out of active runtime
- `backups/original/` — original preserved source copies
- `backups/legacy/` — old/duplicate files that could conflict with Vite/Firebase/Sandbox

## Notes
- `node_modules/`, `.git/`, `.firebase/`, and `dist/` were removed from the archive because they are generated or local-only.
- Run `npm install` before `npm run dev` or `npm run build`.
